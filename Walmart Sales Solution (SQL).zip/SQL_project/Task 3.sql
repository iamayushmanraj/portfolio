##----Analyzing Customer Segmentation Based on Spending ---##

with avg_spend as
(select customer_id, round(avg(total)) as avg_spending from walmart
group by customer_id
order by avg_spending)

select customer_id, avg_spending,
case when avg_spending<300 then "Low"
when avg_spending between 305 and 340 then "medium"
else "high"
end as Tiers
from avg_spend;

###----Criteria includes <300(Low), between 305 and 340(medium), else(high)---## 