##---Best Product Line by Customer Type--##

select * from walmart;

select customer_type, product_line, counts from
(select customer_type, product_line, 
count(product_line) as counts, rank() over(partition by customer_type order by count(product_line) desc) as rnk
from walmart
group by Product_line, customer_type) as b
where rnk=1;

##---Subqueries to determine the count of each product line and filtered to find the most preferred prodcut line by customer type--##