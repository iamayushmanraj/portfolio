##--Analyzing Sales Trends by Day of the Week--##

select * from walmart;

select day_week, sales from
(select dayname(str_to_date(date, "%d-%m-%Y")) as day_week,
round(sum(total)) as sales, rank() over(order by round(sum(total)) desc) as rnk from walmart
group by day_week) as b

##--Using the dayname function to extract day from the "date" column and grouped it for further comparision--##