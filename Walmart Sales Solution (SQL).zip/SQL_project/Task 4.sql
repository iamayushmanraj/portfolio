##----Detecting Anomalies in Sales Transactions ##----
select * from walmart;

with cte as(select product_line, round(avg(total)) as avg_sales
from walmart
group by product_line)

select t.product_line, round(t.total) as sales, s.avg_sales
from walmart t
join cte s on
t.product_line=s.product_line;

##--A table is created to compute the average of each product_line##--
##--then self join is used to bring avg_sales parallel to each productline to find anomalies##--