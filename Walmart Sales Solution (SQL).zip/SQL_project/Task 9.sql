##-- Finding Top 5 Customers by Sales Volume --##
select * from walmart;

select customer_id, total_sales_volume from
(select customer_id, round(sum(total)) as total_sales_volume,
rank() over (order by sum(total) desc) as rnk
from walmart
group by Customer_ID) as b
where rnk in(1,2,3,4,5)

##-- The filtered data from subquery return top 5 customers by sales volume--##