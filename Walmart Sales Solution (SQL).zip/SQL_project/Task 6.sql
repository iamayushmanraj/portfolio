###--Monthly Sales Distribution by Gender----##

select * from walmart;

with sales_distribution as
(select gender, round(sum(total)) as sales, 
date_format(str_to_date(date,"%d-%m-%Y"),"%Y-%m") as mths
from walmart group by gender, mths)

select gender, sales, mths from sales_distribution
order by gender;
