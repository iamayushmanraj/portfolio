##----Identifying Repeat Customers---##

select * from walmart;
select distinct w1.customer_id
from walmart w1
join walmart w2
on w1.Customer_ID=w2.Customer_ID
where w2.date>w1.date
and datediff(str_to_date(w2.date,"%d-%m-%Y"),str_to_date(w1.date,"%d-%m-%Y"))<=30;

##-- Using self-join to bring all the dates together and comparing each other to find repeat customers--##