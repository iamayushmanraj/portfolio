##--Most Popular Payment Method by City---##

with trn_count as
(select city, payment, count(payment) as payment_count,
dense_rank() over(partition by city order by count(payment) desc) as rnk
from walmart
group by city, payment)

select city, payment, payment_count
from trn_count 
where rnk=1
order by payment_count desc;

##---- Results say, Yangaon - "Ewallet", Naypyitaw-Cash", and Mandalay-"Ewallet"