##--Finding the Most Profitable Product Line for Each Branch--##

select * from walmart;

select branch, product_line, total_profit_margin, rnk from
(select branch, product_line, round(sum(gross_income-cogs)) as total_profit_margin,
rank() over (partition by branch order by sum(gross_income-cogs) desc) as rnk
from walmart group by branch, product_line) as rnk
where rnk=1;

##--With the help to sub-query the contribution of product line to each branch--##
