##---Identifying the Top Branch by Sales Growth Rate---##

with sales_over_month as
(select branch, date_format(str_to_date (date,"%d-%m-%Y"),"%Y-%m") as year_monthname,
round(sum(total)) as monthly_sales
from walmart
group by branch, year_monthname)

select branch,year_monthname, monthly_sales, 
lag(monthly_sales) over(partition by branch order by year_monthname) as previous_sales,
case when lag(monthly_sales) over(partition by branch order by year_monthname) is null then NULL
else (monthly_sales - lag(monthly_sales) over(partition by branch order by year_monthname))/
nullif(lag(monthly_sales) over(partition by branch order by year_monthname),0)*100
end as growth_rate
from sales_over_month
order by branch;

##----- Analysing the average growth rate to find the top branch by sales------##

with sales_walmart as
(select branch, date_format(str_to_date (date,"%d-%m-%Y"),"%Y-%m") as year_monthname,
round(sum(total)) as monthly_sales
from walmart
group by branch, year_monthname),
growth as (select branch, monthly_sales, lag(monthly_sales) over(partition by branch 
order by year_monthname) as previous_sales from sales_walmart)

select branch, round(avg((monthly_sales-previous_sales)/Nullif(previous_sales,0)*100)) as avg_growth_rate
from growth
group by branch
order by avg_growth_rate desc
limit 1;

##---- Branch A is top branch a/c to analysis----##